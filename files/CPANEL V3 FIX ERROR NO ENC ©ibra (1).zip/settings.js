const chalk = require("chalk")
const fs = require("fs")



global.owner = ['6282281704226'] //ur owner number
global.ownernomer = "6282281704226" //ur owner number2
global.ownername = "𝐅𝐚𝐚𝐧𝐳𝐲𝐇𝐎𝐒𝐓" //ur owner name
global.grup = false //ur group link
global.yt = "https://whatsapp.com/channel/0029Vaol9Mq8kyyPJC4wCD2l" //ur website link
global.socialm = "GitHub: " //ur github or insta name
global.location = "Indonesia" //ur location

//payment ----- lu tau lah diubah jadi apaan
global.dana = "0882281704226"
global.ovo = "0882281704226"
global.gopay = "082120137320"
global.saweria = "https://saweria.co/Faanzystore"

//new
global.ownergc = "https://whatsapp.com/channel/0029Vaol9Mq8kyyPJC4wCD2l"
global.botname = "𝐅𝐚𝐚𝐧𝐳𝐲𝐇𝐎𝐒𝐓"
global.ownerNumber = ["6283865634370@s.whatsapp.net"]
global.ownerweb = "𝐅𝐚𝐚𝐧𝐳𝐲𝐇𝐎𝐒𝐓"
global.themeemoji = '🪀'
global.wm = "-"
global.packname = "𝐅𝐚𝐚𝐧𝐳𝐲𝐇𝐎𝐒𝐓"
global.author = "faan\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.domain = 'https://faanzyhost.server-vip.web.id' // Isi Domain Lu
global.apikey = 'ptla_CEjEWrfgpTGNt1Mh1JFY3youdVtW3B8zoTvoyl0w9Lk' // Isi Apikey Plta Lu
global.capikey = 'ptlc_jQQRxJ11jgKMNVBkHdqbUzIeAFgcLqcfgQkdNLKG93t' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipake
global.location = '1' // id location

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumbmenu ='https://files.catbox.moe/mxva5z.jpg'

global.thumb = { url: 'https://files.catbox.moe/mxva5z.jpg' }
global.defaultpp = 'https://files.catbox.moe/mxva5z.jpg' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

global.listharga = `*𝐅𝐚𝐚𝐧𝐳𝐲𝐇𝐎𝐒𝐓 MENYEDIAKAN*

PANEL UNLI 4K
RESELLER 5K
ADP 10K
PT PANEL 15K
OWN PANEL 20K

ANTI PT"
PERMANEN
HIGH SERVER QUALITY
R16C4

*_JASTEB_*

_JASTEB 100+ RESS - 5K_
_JASTEB 200+ RESS - 10K_
_JASTEB 300+ RESS - 15K_
_JASTEB VIP RESS - 20K_
_JASTEB VVIP RESS - 25K_

*KEBUTUHAN JASTEB*

_PT JASTEB 1 MAIL - 10K_
_TEAM RESS - 20K_
_SEWA PANEL JASTEB - 15K_

*_OPEN UNCHEK_*

_50 UNCHEK - 5K_
_100 UNCHEK - 10K_
_150 UNCHEK - 15K_

*DAN BARANG LAIN JUGA*

_JASA RENAME SC_
_MURID BACKDOOR_
_MURID NOKOS_
_PANEL BOT WA_

MINAT?? PM
wa.me/6282281704226
t.me/FaanzyHOST
TESTI?
https://whatsapp.com/channel/0029Vaol9Mq8kyyPJC4wCD2l
`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
